// Content script to forward payment token from page to background
window.addEventListener('browserbaseTokenSet', (e) => {
  const detail = e.detail || {};
  if (detail.type === 'SET_PAYMENT_TOKEN' && detail.token) {
    chrome.runtime.sendMessage({ type: 'SET_PAYMENT_TOKEN', token: detail.token });
  }
})